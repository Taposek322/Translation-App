package com.taposek322.translationapp.data.db.room

object TranslationDataBaseObject {
    const val databaseName = "TranslationDB"
}