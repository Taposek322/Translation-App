package com.taposek322.translationapp.presentation.ui.recyclerView

import androidx.recyclerview.widget.RecyclerView
import com.taposek322.translationapp.databinding.TranslationResultBinding

class HistoryViewHolder(
    val binding: TranslationResultBinding
):RecyclerView.ViewHolder(binding.root) {
}